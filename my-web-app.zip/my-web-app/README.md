# My Web App

## Steps to Run the Application

### Backend

1. Navigate to the backend directory:
    ```bash
    cd backend
    ```
2. Install dependencies:
    ```bash
    npm install
    ```
3. Start the TypeScript compiler in watch mode:
    ```bash
    tsc -w
    ```
4. Start the backend server:
    ```bash
    npm start
    ```

### Frontend

1. Navigate to the frontend directory:
    ```bash
    cd frontend
    ```
2. Install dependencies:
    ```bash
    npm install
    ```
3. Start the frontend development server:
    ```bash
    npm start
    ```

### Compress the Application

Run `npm run zip` to generate the `my-web-app.zip` file, which can be downloaded and shared.