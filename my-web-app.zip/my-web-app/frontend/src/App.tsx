import React from 'react';
import Navbar from './components/Navbar';

const App: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-100">
      <Navbar />
      <div className="container mx-auto p-4">
        <h1 className="text-2xl font-bold">Welcome to My Web App</h1>
        {/* Additional content */}
      </div>
    </div>
  );
};

export default App;