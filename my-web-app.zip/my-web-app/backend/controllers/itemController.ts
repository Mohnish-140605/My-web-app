import { Request, Response } from 'express';
import Item from '../models/itemModel';

const getItems = async (req: Request, res: Response): Promise<void> => {
  try {
    const items = await Item.find();
    res.json(items);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Other controller functions similarly typed...

export { getItems, createItem, updateItem, deleteItem };